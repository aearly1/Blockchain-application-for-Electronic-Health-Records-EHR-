const lab_visits_data = [
    {
        id: 1, // visit id  
        patient_id: 1,
        patient_name: "Obaya",
        date: "10-10-2021",
        readings: "xray turns you sad",
        results: "high amounts of radiation"
      },
      {
        id: 2,
        patient_id: 1,
        patient_name: "Obaya",
        date: "10-10-2021",
        readings: "xray turns you sad",
        results: "high amounts of radiation"
      },
      {
        id: 3,
        patient_id: 2,
        patient_name: "Ali El badry",
        date: "10-10-2021",
        readings: "xray turns you sad",
        results: "high amounts of radiation"
      },
      {
        id: 4,
        patient_id: 2,
        patient_name: "Ali El badry",
        date: "10-10-2021",
        readings: "xray turns you sad",
        results: "high amounts of radiation"
      },
      {
        id: 5,
        patient_id: 3,
        patient_name: "Mokhtar",
        date: "10-10-2021",
        readings: "xray turns you sad",
        results: "high amounts of radiation"
      }
]

const getLabVisitsData = () => lab_visits_data;

export default getLabVisitsData;