const normal_visits_data = [
    {
        id: 1, // visit id  
        patient_id: 1,
        patient_name: "Obaya",
        date: "10-10-2021",
        readings: "Blood pressure: 130, pulse: 80, oxygen level: 95%",
        reason: "High blood pressure",
        diagnosis:"Anger",
        prescription:"1mg anti-anger pill once a day, further lab tests"
      },
      {
        id: 2,
        patient_id: 1,
        patient_name: "Obaya",
        date: "10-10-2021",
        readings: "Blood pressure: 130, pulse: 80, oxygen level: 95%",
        reason: "High blood pressure",
        diagnosis:"Anger",
        prescription:"1mg anti-anger pill once a day, further lab tests"
      },
      {
        id: 3,
        patient_id: 2,
        patient_name: "Ali El badry",
        date: "10-10-2021",
        readings: "Blood pressure: 130, pulse: 80, oxygen level: 95%",
        reason: "High blood pressure",
        diagnosis:"Anger",
        prescription:"1mg anti-anger pill once a day, further lab tests"
      },
      {
        id: 4,
        patient_id: 2,
        patient_name: "Ali El badry",
        date: "10-10-2021",
        readings: "Blood pressure: 130, pulse: 80, oxygen level: 95%",
        reason: "High blood pressure",
        diagnosis:"Anger",
        prescription:"1mg anti-anger pill once a day, further lab tests"
      },
      {
        id: 5,
        patient_id: 5,
        patient_name: "Nader",
        date: "10-10-2021",
        readings: "Blood pressure: 130, pulse: 80, oxygen level: 95%",
        reason: "High blood pressure",
        diagnosis:"Anger",
        prescription:"1mg anti-anger pill once a day, further lab tests"
      }
]

const getNormalVisitsData = () => normal_visits_data;

export default getNormalVisitsData;
