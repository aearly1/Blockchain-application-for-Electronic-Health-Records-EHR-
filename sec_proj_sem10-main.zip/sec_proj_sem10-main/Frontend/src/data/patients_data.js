const patients_data = [
    {
      id: 1,
      name: 'Obaya',
      age: 22,
      weight: 95,
      height: 177,
      sex: 'male',
      medical_history: "Blood pressure: 90, pulse: 56, oxygen level: 86%"
    },
    {
      id: 2,
      name: 'Ali El badry',
      age: 22,
      weight: 95,
      height: 190,
      sex: 'male',
      medical_history: "Blood pressure: 90, pulse: 56, oxygen level: 86%"
    },
    {
      id: 3,
      name: 'Mokhtar',
      age: 22,
      weight: 80,
      height: 180,
      sex: 'male',
      medical_history: "Blood pressure: 90, pulse: 56, oxygen level: 86%"
    },
    {
      id: 4,
      name: 'Emad',
      age: 22,
      weight: 70,
      height: 174,
      sex: 'male',
      medical_history: "Blood pressure: 90, pulse: 56, oxygen level: 86%"
    },
    {
      id: 5,
      name: 'Nader',
      age: 23,
      weight: 95,
      height: 181,
      sex: 'male',
      medical_history: "Blood pressure: 90, pulse: 56, oxygen level: 86%"
    }
]

const getPatientsData = () => patients_data;

export default getPatientsData;