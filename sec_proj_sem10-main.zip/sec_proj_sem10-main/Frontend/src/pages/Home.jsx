import AddPatient from '../components/AddPatient';
import AddVisit from '../components/AddVisit';
import PatientList from '../components/PatientList';

const Home = ({username, 
                toggleAddPatientForm, addPatientForm, 
                toggleAddVisitForm, addVisitForm, 
                newPatient, setNewPatient, 
                newVisit, setNewVisit, 
                newLabVisit, setNewLabVisit,
                visits, setVisits, labVisits, setLabVisits, patients, setPatients, accountInfo}) =>(
    <>
        <div className="add-btns">
            <AddPatient toggleAddPatientForm={toggleAddPatientForm} 
                        addPatientForm={addPatientForm} 
                        patients={patients} setPatients={setPatients}
                        accountInfo={accountInfo}/>

            <AddVisit toggleAddVisitForm={toggleAddVisitForm} addVisitForm={addVisitForm}
                        newVisit={newVisit} setNewVisit={setNewVisit} 
                        newLabVisit={newLabVisit} setNewLabVisit={setNewLabVisit}  
                        patients={patients} visits={visits} setVisits={setVisits} labVisits={labVisits} setLabVisits={setLabVisits} 
                        accountInfo={accountInfo}/>
        </div>
        
        <PatientList patients={patients} />
    </>
)

export default Home