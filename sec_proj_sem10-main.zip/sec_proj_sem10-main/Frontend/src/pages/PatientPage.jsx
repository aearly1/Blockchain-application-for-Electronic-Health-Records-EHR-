import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom'
import Patient from '../components/Patient'
import VisitsList from '../components/VisitsList';
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft, faPills, faVial } from '@fortawesome/free-solid-svg-icons'

const PatientPage = ({username, patients, visits, labVisits}) => {
    const [ visitsLab, setVisitsLab ] = useState(false) // false --> normal visits, true --> lab visits
    const [ shownVisits, setShownVisits ] = useState([]) 
    const [ visitType, setVisitType ] = useState(false)
    const params = useParams();
    const pid= parseInt(params.id)
    const patient= patients.find(p => p.id === pid) 
    // console.log(pid);
    const toggleVisitsLab = () => {
        setVisitsLab(!visitsLab)
        setVisitType(!visitType)
    }
    useEffect(() => {
        const tmp = visitsLab ? labVisits : visits;
        setShownVisits(tmp.filter(v => v.patient_id === pid))
    },[visitsLab])
    // console.log(visits, labVisits, shownVisits);
    return(
        <>  
            
            <div className="patient-btns">
                <Link style={{ textDecoration: 'inherit'}} to="/" className="patient-btns-back">
                    <FontAwesomeIcon icon={faArrowLeft} style={{marginRight: "1em"}}/>
                    Back
                </Link>
            </div>
            {   patient &&
                <Patient patient={patient} visitsLab={visitsLab} toggleVisitsLab={toggleVisitsLab}/>
            }
            <div className="switch-container">
                <FontAwesomeIcon className={`${visitsLab ? `switch-icon`: `switch-icon-active`}`} icon={faPills} style={{marginRight: "1em"}}/>
                <label className="switch">
                    <input type="checkbox" onClick={toggleVisitsLab}/>
                    <span className="slider round"></span>
                </label>
                <FontAwesomeIcon className={`${visitsLab ? `switch-icon-active`: `switch-icon`}`} icon={faVial} style={{marginLeft: "1em"}}/>
            </div>
            {<VisitsList visits={shownVisits} visitsLab={visitsLab}/>}
        </>
    )
}

export default PatientPage