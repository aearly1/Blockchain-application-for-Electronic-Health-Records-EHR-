import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
import Select from 'react-select'
import { useEffect, useState } from 'react';
import Web3 from 'web3/dist/web3.min'
import { CONTACT_ABI, MNEMONIC, CONTACT_ADDRESS } from './config';

import EthCrypto from 'eth-crypto';
//import ecies from "eth-ecies";
import * as ecies from "ecies-geth";
import util from 'ethereumjs-util'

const AddVisit = ({toggleAddVisitForm, addVisitForm, newVisit, setNewVisit, 
                    newLabVisit, setNewLabVisit, visits, setVisits, labVisits, setLabVisits,  patients, accountInfo}) =>{ 
    
    const [account, setAccount] = useState();
    const [contract, setContract] = useState();
    const [ visitType, setVisitType ] = useState("Normal"); 
    const [ filterNames, setFilterNames ] = useState([]);
    // const [ filterIDs, setFilterIDs ] = useState([]);
    // visit attributes
    const [ patientName, setPatientName ] = useState("");
    const [ patientID, setPatientID ] = useState("");
    const [ date, setDate ] = useState("");
    const [ readings, setReadings ] = useState("");
    const [ reason, setReason ] = useState("");
    const [ diagnosis, setDiagnosis ] = useState("");
    const [ prescription, setPrescription ] = useState("");
    const [ results, setResults ] = useState("");
    const [ newVisito, setNewVisito ] = useState();

    useEffect(() => {
        setFilterNames(patients.map(p => ({value: p.name, label: p.name, id: p.id})))
        // setFilterIDs(filterNames.map(p => p.id))

        async function sendData() {
            const web3 = new Web3(Web3.givenProvider || 'http://18.118.132.239:8545');
            const accounts = await web3.eth.requestAccounts();
            setAccount(accountInfo.address);
            // Instantiate smart contract using ABI and address.
            const contr = new web3.eth.Contract(CONTACT_ABI, CONTACT_ADDRESS);
            // set contract to state variable.
            setContract(contr);

            // address and private key (in frontend you should get them from ganache)
            // const accountInfo = {
            //     address: '0x5e471D8BDA2E7F905E9fB22c726b86Ba813bacd0',
            //     privateKey: 'ca6c1c8aca056a1f5e1e5b6f180d9b1d2a5aa62e7173d484854e70a7104d4a6c',
            // }
            // // get public key from private key (no other way)
            // let privateBuffer = new Buffer(accountInfo.privateKey, 'hex');
            // accountInfo.publicKey = util.privateToPublic(privateBuffer).toString('hex')
            //encrypt visit
            const enc_sig = await encrypt_sign(newVisito, accountInfo);
            const hexEncrypted = enc_sig[0];
            const encryptedHash = enc_sig[1];
            const signature = enc_sig[2];
            setNewVisito();
            await contr.methods.addVisit(hexEncrypted, newVisito.patient_id, encryptedHash, signature).send({from: accountInfo.address});
        }
        if(newVisito != null)
            sendData();
        /**
 * 
 * @param {data} message to be encrypted in JSON format 
 * @param {account} JSON Account containing private and public keys
 * @returns encrypted data in hexadecimal, hash of encryoted data, digital signature
 */
async function encrypt_sign(data, account){
    data = JSON.stringify(data)
  
    const encrypted = await encrypt(account.publicKey, data);
    const encryptedHash = EthCrypto.hash.keccak256(encrypted);
    const signature = EthCrypto.sign(account.privateKey, encryptedHash);
    const hexEncrypted = "0x" + new Buffer(JSON.stringify(encrypted)).toString('hex');
  
    return [hexEncrypted, encryptedHash, signature];
  }
  
  /**
   * 
   * @param {cipher} ciphertext to be decrypted in hexadecimal
   * @param {account} JSON Account containing private key
   * @returns JSON object of decrypted ciphertext
   */
  function recover_data(cipher, account){
    const encrypted = new Buffer(cipher.substring(2), 'hex').toString();
    var recovered_data = decrypt(account.privateKey, encrypted)
    recovered_data = JSON.parse(recovered_data);
  
    return recovered_data;
  }
  
  /**
   * 
   * @param {publicKey} a hexadecimal string
   * @param {data} string data
   * @returns ciphertext
   */
  async function encrypt(publicKey, data) {
    let userPublicKey = Buffer(publicKey, 'hex');
    let bufferData = Buffer(data);
    let encryptedData = await ecies.encrypt(userPublicKey, bufferData);
  
    return encryptedData.toString('base64')
  }
  
  /**
   * 
   * @param {privateKey} a hexadecimal string
   * @param {encryptedData} base64 string encrypted data
   * @returns message string
   */
  async function decrypt(privateKey, encryptedData) {
    let userPrivateKey = new Buffer(privateKey, 'hex');
    let bufferEncryptedData = new Buffer(encryptedData, 'base64');
  
    let decryptedData = await ecies.decrypt(userPrivateKey, bufferEncryptedData);
    
    return decryptedData.toString('utf8');
  }
    },[toggleAddVisitForm])
    
    const handleVisitType = e => setVisitType(e.target.value)
    // handling visits attributes
    const handlePatientName = e => {
        setPatientName(e.value)
        const tmpP = patients.find(p => p.name === e.value)
        setPatientID(tmpP.id)
    }
    const handleDate = e => setDate(e.target.value)
    const handleReadings = e => setReadings(e.target.value)
    const handleReason = e => setReason(e.target.value)
    const handleDiagnosis = e => setDiagnosis(e.target.value)
    const handlePrescription = e => setPrescription(e.target.value)
    const handleResults = e => setResults(e.target.value)

    const handleVisitSubmit = e => {
        e.preventDefault();

        // security is done here
        if (visitType === "Normal"){
            const newTmp = {
                id: visits.length,
                prev_visit_id: visits.length - 1,
                patient_id: patientID,
                patient_name: patientName,
                date: date,
                readings: readings,
                reason: reason,
                diagnosis:diagnosis,
                prescription: prescription
            }
            setNewVisito(newVisito=>newTmp)
            setVisits(visits => [...visits, newTmp]) // newvisits = oldvisits + newVisit
        }else if (visitType === "Lab"){
            const newTmp = {
                id: visits.length,
                patient_id: patientID,
                patient_name: patientName,
                date: date,
                readings: readings,
                results: results
            }
            setNewVisito(newVisito=>newTmp)
            setLabVisits(labVisits => [...labVisits, newTmp]) // newLabvisits = oldLabvisits + newLabVisit

        }
        alert("Visit have been added successfully !")
        
        e.target.reset();
        toggleAddVisitForm();
    }
    const selectStyles = {
        control: (base, state) => ({
          ...base,
          display: "flex",
          justifyContent: "center",
          margin: "1em auto",
          padding: "0.5em",
          width: "20em",
          borderRadius: "30px",
          
        }),
        menu: (base, state) => ({
            ...base,
            //width: "20em",
          })
    } 
    //console.log("visit type: ", visitType, "patient: ", patientName, "pid: ", patientID, "Date:", date ,"readings: ", readings);
    return(
        <div className="add-visit">
            <div className={addVisitForm ? `d-none`: `add-visit-container`}>
                <div className="add-visit-container-btn" onClick={toggleAddVisitForm}>
                    <FontAwesomeIcon style={{marginRight: "1em"}} icon={faPlus} />New Visit 
                </div>
            </div>
            <div className={addVisitForm ?  `add-visit-formcontainer` : `d-none`}>
                <form className="add-visit-form" onSubmit={handleVisitSubmit}>
                    <div className="add-visit-form-inputs" >
                        <select onChange={handleVisitType}>
                            <option className="hidden_option" selected disabled>Type of Visit</option>
                            <option >Normal</option>
                            <option >Lab</option>
                        </select>
                        <Select className="add-visit-form-inputs-select"
                                id = "form_patientName" 
                                styles={selectStyles}
                                isFocused={false} 
                                //value={searchTerm} 
                                value={filterNames.find(obj => obj.value === patientName)} // set selected value
                                options={filterNames} 
                                placeholder="Patient Name"
                                onChange={handlePatientName}/>
                        <input  type="date" 
                                id = "form_date" 
                                placeholder="Date" 
                                onChange={handleDate}/>
                        <input  type="text" 
                                id = "form_readings" 
                                placeholder="Readings" 
                                onChange={handleReadings}/>
                        <input className={`${visitType=="Lab" ? "" : "d-none"}`} 
                                id="form_results" 
                                type="text" 
                                placeholder="Results" 
                                onChange={handleResults}/>
                        <input className={`${visitType=="Normal" ? "" : "d-none"}`} 
                                id="form_reason" 
                                type="text" 
                                placeholder="Reason" 
                                onChange={handleReason}/>
                        <input className={`${visitType=="Normal" ? "" : "d-none"}`} 
                                id="form_diagnosis" 
                                type="text" 
                                placeholder="Diagnosis" 
                                onChange={handleDiagnosis}/>
                        <input className={`${visitType=="Normal" ? "" : "d-none"}`} 
                                id="form_prescription" 
                                type="text" 
                                placeholder="Prescription" 
                                onChange={handlePrescription}/>
                        
                    </div>
                    <div className="add-visit-form-btns">
                        <div className="add-visit-form-btns-btn" onClick={toggleAddVisitForm}>
                            cancel
                        </div>
                        <div className="add-visit-form-btns-btn">
                            <input type="submit" className="add-visit-form-btns-btn-submit"/>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    )
}
export default AddVisit

