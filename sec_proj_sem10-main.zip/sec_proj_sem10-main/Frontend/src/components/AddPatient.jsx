import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus } from '@fortawesome/free-solid-svg-icons'
import { useEffect, useState } from 'react';
import Web3 from 'web3/dist/web3.min'
import { CONTACT_ABI, MNEMONIC, CONTACT_ADDRESS } from './config';

import EthCrypto from 'eth-crypto';
//import ecies from "eth-ecies";
import * as ecies from "ecies-geth";
import * as util from 'ethereumjs-util'

const AddPatient = ({toggleAddPatientForm, addPatientForm, patients, setPatients, accountInfo}) => {
    const [account, setAccount] = useState();
    const [contract, setContract] = useState();
    const [ patientName, setPatientName ] = useState("");
    const [ age, setAge ] = useState(0);
    const [ weight, setWeight ] = useState(0);
    const [ height, setHeight ] = useState(0);
    const [ sex, setSex ] = useState("male");
    const [ medicalHistory, setMedicalHistory ] = useState("male");
    const [ newPatient, setNewPatient ] = useState();
    //console.log(util);
    const handlePatientName = e => setPatientName(e.target.value)
    const handleAge = e => setAge(e.target.value)
    const handleWeight = e => setWeight(e.target.value)
    const handleHeight = e => setHeight(e.target.value)
    const handleSex = e => setSex(e.target.value)
    const handleMedicalHistory = e =>setMedicalHistory(e.target.value)

    const handlePatientSubmit = e => {
        e.preventDefault();
        
        // form result
        const tmpP = {
            id: patients.length,
            name: patientName,
            age: age,
            weight: weight,
            height: height,
            sex: sex,
            medical_history: medicalHistory
        }
        setNewPatient(tmpP)
        setPatients(patients => [...patients, tmpP]) // newpatients = oldpatients + newPatient
        alert("Patient have been added successfully !")
        
        e.target.reset();
        toggleAddPatientForm();
    }

    useEffect(() => {
        async function sendData() {
            const web3 = new Web3(Web3.givenProvider || 'http://18.118.132.239:8545');
            const accounts = await web3.eth.requestAccounts();
            setAccount(accountInfo.address);
            // Instantiate smart contract using ABI and address.
            const contr = new web3.eth.Contract(CONTACT_ABI, CONTACT_ADDRESS);
            // set contract to state variable.
            setContract(contr);

            // address and private key (in frontend you should get them from ganache)
            // const accountInfo = {
            //     address: '0x5e471D8BDA2E7F905E9fB22c726b86Ba813bacd0',
            //     privateKey: 'ca6c1c8aca056a1f5e1e5b6f180d9b1d2a5aa62e7173d484854e70a7104d4a6c',
            // }
            // // get public key from private key (no other way)
            // let privateBuffer = new Buffer(accountInfo.privateKey, 'hex');
            // accountInfo.publicKey = util.privateToPublic(privateBuffer).toString('hex')

            
            //encrypt patient
            //console.log(newPatient);
            //console.log(newPatient != null)
            const enc_sig = await encrypt_sign(newPatient, accountInfo);
            const hexEncrypted = enc_sig[0];
            const encryptedHash = enc_sig[1];
            const signature = enc_sig[2];

            setNewPatient();

            const shaka = await contr.methods.addPatient(hexEncrypted, encryptedHash, signature).send({from: accountInfo.address});
          }
          
          if(newPatient != null)
            sendData();

        /**
 * 
 * @param {data} message to be encrypted in JSON format 
 * @param {account} JSON Account containing private and public keys
 * @returns encrypted data in hexadecimal, hash of encryoted data, digital signature
 */
async function encrypt_sign(data, account){
    data = JSON.stringify(data)
  
    const encrypted = await encrypt(account.publicKey, data);
    const encryptedHash = EthCrypto.hash.keccak256(encrypted);
    const signature = EthCrypto.sign(account.privateKey, encryptedHash);
    const hexEncrypted = "0x" + new Buffer(JSON.stringify(encrypted)).toString('hex');

    return [hexEncrypted, encryptedHash, signature];
  }
  
  /**
   * 
   * @param {cipher} ciphertext to be decrypted in hexadecimal
   * @param {account} JSON Account containing private key
   * @returns JSON object of decrypted ciphertext
   */
  async function recover_data(cipher, account){
    const encrypted = new Buffer(cipher.substring(2), 'hex').toString();
    var recovered_data = await decrypt(account.privateKey, encrypted)
    recovered_data = JSON.parse(recovered_data);
  
    return recovered_data;
  }
  
  /**
   * 
   * @param {publicKey} a hexadecimal string
   * @param {data} string data
   * @returns ciphertext
   */
  async function encrypt(publicKey, data) {
    let userPublicKey = Buffer(publicKey, 'hex');
    //console.log(typeof data);

    let bufferData = Buffer(data);
    //console.log(userPublicKey);
    //console.log(bufferData);
    let encryptedData = await ecies.encrypt(userPublicKey, bufferData);
  
    return encryptedData.toString('base64')
  }
  
  /**
   * 
   * @param {privateKey} a hexadecimal string
   * @param {encryptedData} base64 string encrypted data
   * @returns message string
   */
  async function decrypt(privateKey, encryptedData) {
    let userPrivateKey = new Buffer(privateKey, 'hex');
    let bufferEncryptedData = new Buffer(encryptedData, 'base64');
  
    let decryptedData = await ecies.decrypt(userPrivateKey, bufferEncryptedData);
    
    return decryptedData.toString('utf8');
  }
    },[toggleAddPatientForm])

    //console.log("patient: ", patientName, "age: ", age, "sex:", sex ,"height: ", height);

    return(
        <div className="add-patient">
            <div className={addPatientForm ? `d-none`: `add-patient-container`}>
                <div className="add-patient-container-btn" onClick={toggleAddPatientForm}>
                    New Patient <FontAwesomeIcon style={{marginLeft: "1em"}} icon={faPlus} />
                </div>
            </div>
            <div className={addPatientForm ?  `add-patient-formcontainer` : `d-none`}>
                <form className="add-patient-form" onSubmit={handlePatientSubmit}>
                    <div className="add-patient-form-inputs">
                        <input type="text" placeholder="Patient name" onChange={handlePatientName}/>
                        <input type="number" placeholder="age" onChange={handleAge}/>
                        <input type="number" placeholder="weight" onChange={handleWeight}/>
                        <input type="number" placeholder="height" onChange={handleHeight}/>
                        <select onChange={handleSex} value={"male"}>
                            <option className="hidden_option" value={"male"}  disabled>Gender</option>
                            <option vlaue="male">male</option>
                            <option vlaue="female">female</option>
                        </select>
                        <input type="text" placeholder="Medical history" onChange={handleMedicalHistory}/>
                    </div>
                    <div className="add-patient-form-btns">
                        <div className="add-patient-form-btns-btn" onClick={toggleAddPatientForm}>
                            cancel
                        </div>
                        <div className="add-patient-form-btns-btn" type="submit">
                            <input type="submit" className="add-patient-form-btns-btn-submit"/>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    )
}
export default AddPatient

