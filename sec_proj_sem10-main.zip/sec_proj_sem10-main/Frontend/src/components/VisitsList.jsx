
const VisitsList = ({visits}) => {
    
    return(
        <div className="visitsList">
            <div className="visitsList-content">
                {   visits.length > 0 ?
                    visits.map(v => (
                        <dir key={v.id} className="visit">
                            <div className="visit-sub visit-date">
                                <span className="visit-sub-title">Date</span>{v.date}
                            </div>
                            <div className="visit-sub">
                                <span className="visit-sub-title">Patient name</span>{v.patient_name}
                            </div>
                            {   v.reason &&
                                <div className="visit-sub">
                                    <span className="visit-sub-title">Reason</span>{v.reason}
                                </div>
                            }
                            {   v.readings &&
                                <div className="visit-sub">
                                    <span className="visit-sub-title">Readings</span>{v.readings}
                                </div>
                            }
                            {   v.diagnosis &&
                                <div className="visit-sub">
                                    <span className="visit-sub-title">Diagnosis</span>{v.diagnosis}
                                </div>
                            }
                            {   v.prescription &&
                                <div className="visit-sub">
                                    <span className="visit-sub-title">Prescription</span>{v.prescription}
                                </div>
                            }
                            {   v.results &&
                                <div className="visit-sub">
                                    <span className="visit-sub-title">Results</span>{v.results}
                                </div>
                            }
                        </dir>
                    )):
                    <div className="visitsList-content-empty">No Visits yet !</div>
                }
            </div>
        </div>
    )
}

export default VisitsList