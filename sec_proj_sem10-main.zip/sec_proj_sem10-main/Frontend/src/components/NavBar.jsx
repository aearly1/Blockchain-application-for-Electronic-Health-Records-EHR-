import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserDoctor, faStarOfLife } from '@fortawesome/free-solid-svg-icons'
import { Link } from 'react-router-dom';
const NavBar = ({username, token, setIsLogged}) => (
    <div className={`${token ? "header" : "d-none"}`}>
        <div className="header-content">
            <Link style={{color:'inherit', textDecoration: 'inherit'}} className="header-content-logo" to="/">
                <FontAwesomeIcon icon={faStarOfLife} />
                <span className="header-content-logo-text">NMC</span>
            </Link>
            <Link style={{color:'inherit', textDecoration: 'inherit'}} className="header-content-username" to="/login" onClick={() => setIsLogged(false)}>
                {username}  
                <span className="header-content-username-logo"><FontAwesomeIcon icon={faUserDoctor} /></span>
            </Link>
        </div>
    </div>
)

export default NavBar