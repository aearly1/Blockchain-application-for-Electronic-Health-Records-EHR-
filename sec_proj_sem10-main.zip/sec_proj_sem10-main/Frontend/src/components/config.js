export const CONTACT_ADDRESS = '0xCfEB869F69431e42cdB54A4F4f105C19C080A601';
export const MNEMONIC = "myth like bonus scare over problem client lizard pioneer submit female collect"

export const CONTACT_ABI =[
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "internalType": "address",
        "name": "clinic",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "index",
        "type": "uint256"
      }
    ],
    "name": "PatientAddedEvent",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "internalType": "address",
        "name": "clinic",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "patient_index",
        "type": "uint256"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "visit_index",
        "type": "uint256"
      }
    ],
    "name": "VisitAddedEvent",
    "type": "event"
  },
  {
    "constant": false,
    "inputs": [
      {
        "internalType": "bytes",
        "name": "patient",
        "type": "bytes"
      },
      {
        "internalType": "bytes32",
        "name": "hashed",
        "type": "bytes32"
      },
      {
        "internalType": "bytes",
        "name": "signature",
        "type": "bytes"
      }
    ],
    "name": "addPatient",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {
        "internalType": "address",
        "name": "clinic",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "indx",
        "type": "uint256"
      }
    ],
    "name": "getPatient",
    "outputs": [
      {
        "internalType": "bytes",
        "name": "",
        "type": "bytes"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {
        "internalType": "address",
        "name": "clinic",
        "type": "address"
      }
    ],
    "name": "NPatients",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "internalType": "bytes",
        "name": "visit",
        "type": "bytes"
      },
      {
        "internalType": "uint256",
        "name": "patient_indx",
        "type": "uint256"
      },
      {
        "internalType": "bytes32",
        "name": "hashed",
        "type": "bytes32"
      },
      {
        "internalType": "bytes",
        "name": "signature",
        "type": "bytes"
      }
    ],
    "name": "addVisit",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {
        "internalType": "address",
        "name": "clinic",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "patient_indx",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "visit_indx",
        "type": "uint256"
      }
    ],
    "name": "getVisit",
    "outputs": [
      {
        "internalType": "bytes",
        "name": "",
        "type": "bytes"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {
        "internalType": "address",
        "name": "clinic",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "patient_indx",
        "type": "uint256"
      }
    ],
    "name": "NVisits",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  }
];