import { Link } from "react-router-dom"

const PatientList = ({patients}) => (
    <div className="patientlist">
        <div className="patients-content">
            {
                patients.map(p => (
                    <dir key={p.id} className="patient">
                        <div className="patient-name">
                            {p.name}
                        </div>
                        <div className="patient-sub">
                            {p.age && <div className="patient-su-elm">{p.age} years</div>}
                            {p.weight && <div className="patient-sub-elm">{p.weight} kg</div>}
                            {p.height && <div className="patient-sub-elm">{p.height} cm</div>}
                            {p.sex && <div className="patient-sub-elm">{p.sex}</div>}
                        </div>
                        <Link style={{ textDecoration: 'inherit'}} className="patient-btn" to={`/patient/${p.id}`}>Show More</Link>
                    </dir>
                ))
            }
        </div>
    </div>
)

export default PatientList