const PageNotFound = () => <div style={{display: "flex", justifyContent: "center", margin: "2em auto"}}></div>

export default PageNotFound