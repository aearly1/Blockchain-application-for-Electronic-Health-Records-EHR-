import { useEffect, useState } from "react"

const Patient = ({patient, visitsLab, toggleVisitsLab}) =>{
    const [ p, setP] = useState(patient)
    useEffect(() => {
        setP(patient)
    }, [])
    return(
        <div className="patient">
            <div className="patient-content">
                <div className="patient-content-name">
                    {p.name}
                </div>
                <div className="patient-content-sub">
                    {p.age && <div className="patient-content-sub-elm"><span className="patient-content-sub-elm-title">Age</span> {p.age} years</div>}
                    {p.height && <div className="patient-content-sub-elm"><span className="patient-content-sub-elm-title">Height</span> {p.height} cm</div>}
                    {p.weight && <div className="patient-content-sub-elm"><span className="patient-content-sub-elm-title">Weight</span> {p.weight} kg</div>   }
                    {p.sex && <div className="patient-content-sub-elm"><span className="patient-content-sub-elm-title">Sex</span> {p.sex}</div> }  
                    {p.medical_history && <div className="patient-content-sub-elm"><span className="patient-content-sub-elm-title">Medical history</span> {p.medical_history}</div>}   
                </div>
                
            </div>
            <div className="patient-content-btns d-none">
                <div className={`${visitsLab ? `patient-content-btn`: `patient-content-btn-active`}`}>
                    Normal visits
                </div>
                
                <div className={`${visitsLab ? `patient-content-btn-active`: `patient-content-btn`}`}>
                    Lab visits
                </div>
            </div>
        </div>
    )
}

export default Patient