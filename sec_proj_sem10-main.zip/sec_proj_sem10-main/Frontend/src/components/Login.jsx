import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserDoctor } from '@fortawesome/free-solid-svg-icons'
import { Link } from "react-router-dom";
import { useEffect, useState } from 'react';

const Login = ({users, setIsLogged, setUsername, setAccountIndx, setToken}) => {
    const [ username, setUsernameLocal ] = useState('');
    const [ password, setPassword ] = useState('');
    const [ usernames, setUsernames ] = useState([]);
    const [ passwords, setPasswords ] = useState([]);

    const handleUsername = e => setUsernameLocal(e.target.value)
    const handlePassword = e => setPassword(e.target.value)

    useEffect(() => {
        setUsernames(users.map(a => a.username));
        setPasswords(users.map(a => a.password));
    },[])
    // console.log(address, addresses, tmpAddresses);
    return(
        <div className="login">
            <div className="login-container">
                <FontAwesomeIcon icon={faUserDoctor} className="login-icon"/>
                <input type="text" className="login-input" placeholder="Username" onChange={handleUsername}/>
                <input type="text" className="login-input" placeholder="Password" onChange={handlePassword}/>
                <Link style={{ textDecoration: 'inherit'}} to="/" 
                        className="login-btn" 
                        onClick={() => {
                            
                            if(usernames.includes(username) && username !== ''){
                                setUsername(username)

                                if (passwords.includes(password) && password !== ''){
                                    setToken(password)

                                    const userIdx = usernames.indexOf(username)
                                    setAccountIndx(users[userIdx].account);
                                    setIsLogged(true);
                                }
                            }
                                

                            }}>
                    Login
                </Link>
            </div>
        </div>
    )
}

export default Login