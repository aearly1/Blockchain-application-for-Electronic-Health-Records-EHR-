import { useEffect, useState } from 'react'
import './assets/Sass/App.scss'

import {Routes, Route} from "react-router-dom";

import Home from './pages/Home';
import NavBar from './components/NavBar';
import PatientPage from './pages/PatientPage'
import PageNotFound from './components/PageNotFound';

import getPatientsData from './data/patients_data';
import getNormalVisitsData from './data/normal_visits_data';
import getLabVisitsData from './data/lab_visits_data';

import patientsData from './data/patients.json';
import labVisitsData from './data/labVisits.json';
import visitsData from './data/normalVisits.json';
import users from './data/users.json';

import Login from './components/Login';

// import Web3 from 'web3';
import Web3 from 'web3/dist/web3.min'
import { CONTACT_ABI, MNEMONIC, CONTACT_ADDRESS } from './config';
import EthCrypto, { publicKey } from 'eth-crypto';
//import ecies from "eth-ecies";
import * as ecies from "ecies-geth";
import * as util from 'ethereumjs-util'
import * as bip39 from 'bip39'
import hdkey from 'hdkey';
import * as wallet from 'ethereumjs-wallet';
import * as ethers from 'ethers'

const App = () => {
  const [ accountInfo, setAccountInfo ] = useState({});
  const [account, setAccount] = useState();
  const [contract, setContract] = useState();
  const [ isLogged, setIsLogged ] = useState(false) // is logged boolean
  const [ patients, setPatients ] = useState([]); // all patients
  // const [ visitsPatient, setVisitsPatient ] = useState([]);
  const [ visits, setVisits ] = useState([]); // all normal visits
  // const [ labVisitsPatient, setLabVisitsPatient ] = useState([]);
  const [ labVisits, setLabVisits ] = useState([]); // lab visits
  const [ username, setUsername ] = useState(""); // user's username
  const [ addPatientForm, setAddPatientForm] = useState(false); // bool for switching from button to form
  const [ addVisitForm, setAddVisitForm] = useState(false); // bool for switching from button to form
  const [ newPatient, setNewPatient ] = useState({})
  const [ newVisit, setNewVisit ] = useState({})
  const [ newLabVisit, setNewLabVisit ] = useState({})
  const [ token, setToken] = useState();
  const [ accIdx, setAccountIndx] = useState();


  
  const [ addressArr, setAddressArr ] = useState([]) // may be deleted later ya Ali
  //console.log(window.web3.ethereum);
  useEffect(() =>{
    async function load(accountIdx) {
      const web3 = new Web3(Web3.givenProvider || 'http://18.118.132.239:8545');
      const accounts = await web3.eth.requestAccounts();
      
      let mnemonicWallet = ethers.Wallet.fromMnemonic(MNEMONIC, "m/44'/60'/0'/0/"+accountIdx);
      const addr = mnemonicWallet.address
      const private_key = mnemonicWallet.privateKey

      setAccount(addr);
      // Instantiate smart contract using ABI and address.
      const contr = new web3.eth.Contract(CONTACT_ABI, CONTACT_ADDRESS);
      // set contract to state variable.
      setContract(contr);
      // get total number of patients for iteration
      const nPatients= await contr.methods.NPatients(addr).call()
      const nPatientsInt = parseInt(nPatients);

      // address and private key (in frontend you should get them from ganache)
      const accountInfoTmp = {
        address: addr,
        privateKey: private_key.substring(2)
      }
      // get public key from private key (no other way)
      let privateBuffer = new Buffer(accountInfoTmp.privateKey, 'hex');
      //accountInfoTmp.publicKey = util.privateToPublic(privateBuffer).toString('hex')
      accountInfoTmp.publicKey = await ecies.getPublic(privateBuffer);
      setAccountInfo(accountInfoTmp)

      // iterate through the number of patients
      for (var i = 0; i < nPatientsInt; i++) {
        // call the getPatient method to get that particular patient from smart contract
        const patient = await contr.methods.getPatient(accountInfoTmp.address,i).call();
        //decrypt patient
        const recovered_data = await recover_data(patient, accountInfoTmp);
        // add recently fetched patient to state variable.
        setPatients((patients) => [...patients, recovered_data]);
       // setPatients((patients) => [...patients, patient]); // without decryption
      }
      // iterate through the number of patients
      for (var i = 0; i < nPatientsInt; i++) {
        // get total number of normal for iteration
        const nVisits= await contr.methods.NVisits(accountInfoTmp.address,i).call();
        const nVisitsInt = parseInt(nVisits);
        // iterate through the amount of time of counter
        // setVisitsPatient([]);
        // setLabVisitsPatient([]);
        for (var j = 0; j < nVisitsInt; j++) {
          // call the getVisit method to get that particular vist from smart contract
          const vis = await contr.methods.getVisit(accountInfoTmp.address,i,j).call();
          //decrypt visit
          const recovered_data = await recover_data(vis, accountInfoTmp);
          // add recently fetched vis to state variable.

          if(recovered_data.prescription != null){//normal visit  // with encryption 
            setVisits((visits) => [...visits, recovered_data]);
          }
          // if(vis.prescription !=='undefined'){//normal visit // without encryption
          //   setVisits((visits) => [...visits, vis]);
          // }
          else{ //lab visit
            setLabVisits((labVisits) => [...labVisits, recovered_data]); // with encryption 
          // setLabVisits((labVisits) => [...labVisits, vis]); // without encryption
          }
        }
        // setVisits((visits) => [...visits, visitsPatient]);
        // setLabVisits((labVisits) => [...labVisits, labVisitsPatient]);
      }
      
    }
    

    /**
 * 
 * @param {data} message to be encrypted in JSON format 
 * @param {account} JSON Account containing private and public keys
 * @returns encrypted data in hexadecimal, hash of encryoted data, digital signature
 */
async function encrypt_sign(data, account){
  data = JSON.stringify(data)

  const encrypted = await encrypt(account.publicKey, data);
  const encryptedHash = EthCrypto.hash.keccak256(encrypted);
  const signature = EthCrypto.sign(account.privateKey, encryptedHash);
  const hexEncrypted = "0x" + new Buffer(JSON.stringify(encrypted)).toString('hex');

  return [hexEncrypted, encryptedHash, signature];
}

/**
 * 
 * @param {cipher} ciphertext to be decrypted in hexadecimal
 * @param {account} JSON Account containing private key
 * @returns JSON object of decrypted ciphertext
 */
async function recover_data(cipher, account){
  const encrypted = new Buffer(cipher.substring(2), 'hex').toString();
  var recovered_data = await decrypt(account.privateKey, encrypted)
  recovered_data = JSON.parse(recovered_data);

  return recovered_data;
}

/**
 * 
 * @param {publicKey} a hexadecimal string
 * @param {data} string data
 * @returns ciphertext
 */
async function encrypt(publicKey, data) {
  let userPublicKey = Buffer(publicKey, 'hex');
  let bufferData = Buffer(data);

  let encryptedData = await ecies.encrypt(userPublicKey, bufferData);

  return encryptedData.toString('base64')
}

/**
 * 
 * @param {privateKey} a hexadecimal string
 * @param {encryptedData} base64 string encrypted data
 * @returns message string
 */
async function decrypt(privateKey, encryptedData) {
  let userPrivateKey = new Buffer(privateKey, 'hex');
  let bufferEncryptedData = new Buffer(encryptedData, 'base64');
  let decryptedData = await ecies.decrypt(userPrivateKey, bufferEncryptedData);
  
  return decryptedData.toString('utf8');
}
    

    if(isLogged){
      load(accIdx);
    }
    else{
      setUsername("Dr Eggman")

      // getPatients
      //setPatients(patientsData) // set decrypted patients here
      
      
      // decrypt the visits here
      //setVisits(visitsData) // set decrypted visits here
      
      // decrypt the lab visits here
      //setLabVisits(labVisitsData) // set decrypted lab visits here
      
      
      setIsLogged(false)
      setAddressArr(users)
    }
  }, [isLogged])

  // console.log(window.web3);
  //console.log(window.web3.eth);

  const toggleAddPatientForm =()=> setAddPatientForm(!addPatientForm);
  const toggleAddVisitForm =()=> setAddVisitForm(!addVisitForm);
  //console.log(isLogged);
  
  //console.log(token);
  if(!token) {
    return <Login users={users} setIsLogged={setIsLogged} setUsername={setUsername} setToken={setToken} setAccountIndx={setAccountIndx}/>
  }else
  return(
    <>
    <NavBar  username={username} isLogged={isLogged} token={token}/>
      <Routes>
        <Route path="/" exact element={
          <Home username={username} 
                toggleAddPatientForm={toggleAddPatientForm} addPatientForm={addPatientForm} 
                toggleAddVisitForm={toggleAddVisitForm} addVisitForm={addVisitForm}
                newPatient={newPatient} setNewPatient={setNewPatient} 
                newVisit={newVisit} setNewVisit={setNewVisit} 
                newLabVisit={newLabVisit} setNewLabVisit={setNewLabVisit}
                visits={visits} setVisits={setVisits}
                labVisits={labVisits} setLabVisits={setLabVisits}
                patients={patients} setPatients={setPatients}
                accountInfo={accountInfo}/>
        }/>
        <Route path="*"  element={<PageNotFound/>}/>

      </Routes>
      <Routes>
        <Route path="/login" exact element={<Login users={users} setIsLogged={setIsLogged} setUsername={setUsername} setToken={setToken} setAccountIndx={setAccountIndx}/>}/>
        
        <Route path="*"  element={<PageNotFound/>}/>
      </Routes>
      <Routes>
        <Route path="/patient/:id" exact element={
          <PatientPage username={username} patients={patients} visits={visits} labVisits={labVisits}/>
        }/>
        <Route path="*"  element={<PageNotFound/>}/>

      </Routes>
      
    </>
  )
}

export default App
