module.exports = {
  networks: {
    development: {
      host: "18.118.132.239",
      port: 8545,
      network_id: "*"
    }
  },
  compilers: {
    solc: {
      optimizer: {
        enabled: true,
        runs: 200
      }
    }
  }
}
